<?php
/*                                                                        *
 * This script is part of the TYPO3 project - inspiring people to share!  *
 *                                                                        *
 * TYPO3 is free software; you can redistribute it and/or modify it under *
 * the terms of the GNU General Public License version 2 as published by  *
 * the Free Software Foundation.                                          *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General      *
 * Public License for more details.                                       *
 *
 *                                                                        */

/**
 * This finisher sends submitted form data to CampaignMonitor.
 *
 * @author	Reinhard Führicht <rf@typoheads.at>
 * @package	Tx_Formhandler
 * @subpackage	Finisher
 */
class Tx_Formhandler_Validator_CampaignMonitor extends Tx_Formhandler_AbstractValidator {

	/**
	 * Validates the submitted values using given settings
	 *
	 * @param array &$errors Reference to the errors array to store the errors occurred
	 * @return boolean
	 */
	public function validate(&$errors) {

		//First validator returned errors, do nothing
		if(!empty($errors)) {
			return TRUE;
		}

		require_once('CMBase.php');

		$api_key = trim($this->settings['apiKey']);
		$client_id = null;
		$campaign_id = null;
		$list_id = trim($this->settings['listID']);

		$cm = new CampaignMonitor( $api_key, $client_id, $campaign_id, $list_id );
	
		$email = $this->gp['email'];
		$name = $this->gp['firstname'] . ' ' . $this->gp['lastname'];

		$customFields = array(

		);
		
		$result = $cm->subscriberAddWithCustomFields(
			$email, 
			$name,
			$customFields
		);

		if(intval($result['Code']) === 204 || intval($result['Code']) === 208 || intval($result['Code']) === 206) {
			$result = $cm->subscriberAddWithCustomFields(
				$email, 
				$name, 
				$customFields,
				$list_id,
				TRUE
			);

			//User on deleted or bounced list
		} elseif(intval($result['Code']) !== 0) {
			$errors['campaignmonitor'] = $result['Code'];
		}

		return empty($errors);
	}
}
?>
