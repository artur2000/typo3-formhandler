**************************************************************
*** Formhandler - Basic Examples - Field Demo Contact Form ***
**************************************************************

This example will show a simple contact form adding a few probably useless fields just to show how to add them (radio buttons, checkboxes, ...). After the user submitted the form, an email gets sent to an administrator.
The user can choose if he wants to receive a copy of the contact request to the email address entered in the form.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/basic-examples/field-demo-contact-form/ts/ts_setup.txt">
