**************************************************
*** Formhandler - Validation - IsError Markers ***
**************************************************

This example demonstrates how to use isError-Markers to mark erroneous fields. 
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/validation/iserror-markers/ts/ts_setup.txt">
