********************************************************
*** Formhandler - File Upload - Store Uploaded Files ***
********************************************************

This example demonstrates how to create a simple file upload form and move uploaded files to another folder when the form is completed.
This way you can distinguish between files from unfinished and files from finished form submissions.
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/file-upload/store-uploaded-files/ts/ts_setup.txt">
