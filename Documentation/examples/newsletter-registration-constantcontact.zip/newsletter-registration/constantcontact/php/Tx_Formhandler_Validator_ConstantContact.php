<?php
/*                                                                        *
 * This script is part of the TYPO3 project - inspiring people to share!  *
 *                                                                        *
 * TYPO3 is free software; you can redistribute it and/or modify it under *
 * the terms of the GNU General Public License version 2 as published by  *
 * the Free Software Foundation.                                          *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General      *
 * Public License for more details.                                       *
 *
 *                                                                        */

/**
 * This finisher sends submitted form data to Constant Contact.
 *
 * @author	Reinhard Führicht <rf@typoheads.at>
 * @package	Tx_Formhandler
 * @subpackage	Finisher
 */
class Tx_Formhandler_Validator_ConstantContact extends Tx_Formhandler_AbstractValidator {

	/**
	 * Validates the submitted values using given settings
	 *
	 * @param array &$errors Reference to the errors array to store the errors occurred
	 * @return boolean
	 */
	public function validate(&$errors) {

		//First validator returned errors, do nothing
		if(!empty($errors)) {
			return TRUE;
		}

		require_once('constant_contact.php');


		$apiKey = $this->settings['apiKey'];
		$username = $this->settings['username'];
		$password = $this->settings['password'];

		$api = new constant_contact($username, $password, $apiKey, FALSE);

		$params = array (
			'EmailAddress' => $this->gp['email'],
			'FirstName' => $this->gp['firstname'],
			'LastName' => $this->gp['lastname'],
			'OptInSource' => 'ACTION_BY_CUSTOMER'
		);

		$lists = array (
			2
		);

		//$result = $api->add_contact($params, $lists);

		if(substr($result, 0, 5) === 'Error') {
			$errors['constantcontact'] = substr($result, 6,  - 6);
		}

		return empty($errors);
	}
}
?>
