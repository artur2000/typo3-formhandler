*************************************************
*** Formhandler - Validation - Error Messages ***
*************************************************

This example demonstrates how to display error messages. 
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/validation/basic-error-messages/ts/ts_setup.txt">
