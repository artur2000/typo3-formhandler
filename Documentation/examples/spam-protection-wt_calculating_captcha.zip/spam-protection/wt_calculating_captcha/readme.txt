***********************************************************
*** Formhandler - SPAM Protection - Calculating Captcha ***
***********************************************************

This example will show a simple contact form SPAM protected using the extension "wt_calculating_captcha". 
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/spam-protection/wt_calculating_captcha/ts/ts_setup.txt">
