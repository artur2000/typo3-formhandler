*******************************************************
*** Formhandler - Multistep Forms - Job Application ***
*******************************************************

This example demonstrates how to create a multistep job application form.
The form shows a different second step according to the user input of step 1. 
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/multistep-forms/advanced-job-application/ts/ts_setup.txt">
