******************************************************
*** Formhandler - File Upload - Basic File Removal ***
******************************************************

This example demonstrates how to create a form with file upload enabling the user to remove uploaded files.
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/file-upload/basic-file-removal/ts/ts_setup.txt">
