***************************************************
*** Formhandler - Basic Examples - Contact Form ***
***************************************************

This example will show a simple contact form. After the user submitted the form, an email gets sent to an administrator.
The user can choose if he wants to receive a copy of the contact request to the email address entered in the form.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/basic-examples/contact-form/ts/ts_setup.txt">
