*************************************************
*** Formhandler - SPAM Protection - Recaptcha ***
*************************************************

This example will show a simple contact form SPAM protected using the extension "jm_recaptcha". 
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/spam-protection/jm_recaptcha/ts/ts_setup.txt">
