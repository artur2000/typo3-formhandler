**************************************************
*** Formhandler - Data Export - pdf_generator2 ***
**************************************************

This example demonstrates how to enable the user to download a PDF file containing the submitted form data.
After the user submitted the form, an email gets sent to an administrator. A PDF file containing the submitted form data is attached to this email.

The PDF files are generated using the extension webkitpdf.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/data-export/webkitpdf/ts/ts_setup.txt">
